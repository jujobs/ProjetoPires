
import bpy
import os
import re

# ============================================================
# CONFIGURAÇÕES DO PROJETO
# ============================================================

# Pasta que contém os arquivos .glb.
# Exemplo Windows: r"C:\Projeto\frames_3d"
# Exemplo Linux:   "/home/usuario/projeto/frames_3d"
PASTA_GLB = r"D:\jifim\projeto pires\primeiro_teste"

FPS = 30
FRAME_INICIAL = 1

# Quantos frames da animação cada modelo ficará visível.
# Use 1 para trocar de modelo a cada frame da animação.
DURACAO_POR_MODELO = 1

# True: limpa a cena antes de importar.
LIMPAR_CENA = True

# ============================================================
# PREPARAÇÃO
# ============================================================

if not os.path.isdir(PASTA_GLB):
    raise RuntimeError(f"Pasta não encontrada: {PASTA_GLB}")

arquivos = [
    nome for nome in os.listdir(PASTA_GLB)
    if nome.lower().endswith(".glb")
]

# Ordenação natural: frame_2.glb vem antes de frame_10.glb.
def chave_natural(texto):
    return [
        int(parte) if parte.isdigit() else parte.lower()
        for parte in re.split(r"(\d+)", texto)
    ]

arquivos.sort(key=chave_natural)

if not arquivos:
    raise RuntimeError("Nenhum arquivo .glb encontrado na pasta.")

if LIMPAR_CENA:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

# Coleção para organizar os modelos importados.
colecao = bpy.data.collections.get("ANIMACAO_GLB")

if colecao is None:
    colecao = bpy.data.collections.new("ANIMACAO_GLB")
    bpy.context.scene.collection.children.link(colecao)

# ============================================================
# IMPORTAÇÃO E ANIMAÇÃO
# ============================================================

scene = bpy.context.scene
scene.render.fps = FPS
scene.frame_start = FRAME_INICIAL

frame_atual = FRAME_INICIAL
total = len(arquivos)

for indice, nome in enumerate(arquivos):
    caminho = os.path.join(PASTA_GLB, nome)

    # Identifica os objetos existentes antes da importação.
    objetos_antes = set(bpy.data.objects)

    # Importa o GLB.
    bpy.ops.import_scene.gltf(filepath=caminho)

    # Identifica todos os objetos recém-importados.
    novos_objetos = set(bpy.data.objects) - objetos_antes

    if not novos_objetos:
        print(f"AVISO: nenhum objeto importado de {nome}")
        continue

    # Coloca os objetos na coleção da animação.
    for obj in novos_objetos:
        for col in list(obj.users_collection):
            col.objects.unlink(obj)
        colecao.objects.link(obj)

    inicio = frame_atual
    fim = inicio + DURACAO_POR_MODELO - 1

    # Cada modelo só aparece durante seu intervalo.
    for obj in novos_objetos:
        # Esconde antes do início.
        if inicio > FRAME_INICIAL:
            obj.hide_viewport = True
            obj.hide_render = True
            obj.keyframe_insert(
                data_path="hide_viewport",
                frame=inicio - 1
            )
            obj.keyframe_insert(
                data_path="hide_render",
                frame=inicio - 1
            )

        # Mostra no início do intervalo.
        obj.hide_viewport = False
        obj.hide_render = False

        obj.keyframe_insert(
            data_path="hide_viewport",
            frame=inicio
        )
        obj.keyframe_insert(
            data_path="hide_render",
            frame=inicio
        )

        # Mantém visível até o final do intervalo.
        obj.keyframe_insert(
            data_path="hide_viewport",
            frame=fim
        )
        obj.keyframe_insert(
            data_path="hide_render",
            frame=fim
        )

        # Esconde imediatamente após o intervalo.
        obj.hide_viewport = True
        obj.hide_render = True

        obj.keyframe_insert(
            data_path="hide_viewport",
            frame=fim + 1
        )
        obj.keyframe_insert(
            data_path="hide_render",
            frame=fim + 1
        )

        # Trocas instantâneas, sem interpolação gradual.
    
if obj.animation_data and obj.animation_data.action:
    action = obj.animation_data.action

    # Compatibilidade com versões recentes do Blender.
    if hasattr(action, "fcurves"):
        curvas = action.fcurves
        for fc in curvas:
            for key in fc.keyframe_points:
                key.interpolation = "CONSTANT"
    else:
        # A nova API pode armazenar curvas em layers e strips.
        for layer in action.layers:
            for strip in layer.strips:
                if hasattr(strip, "channelbag"):
                    bag = strip.channelbag(
                        obj,
                        ensure=False
                    )
                    if bag:
                        for fc in bag.fcurves:
                            for key in fc.keyframe_points:
                                key.interpolation = "CONSTANT"


    print(
        f"[{indice + 1}/{total}] {nome}: "
        f"frames {inicio}-{fim}"
    )

    frame_atual = fim + 1

# ============================================================
# FINALIZAÇÃO
# ============================================================

scene.frame_end = frame_atual - 1
scene.frame_set(FRAME_INICIAL)

print("====================================")
print("ANIMAÇÃO CRIADA COM SUCESSO")
print(f"Modelos encontrados: {total}")
print(f"FPS: {FPS}")
print(f"Frames: {scene.frame_start} - {scene.frame_end}")
print("Confira a animação na Timeline.")
print("====================================")
