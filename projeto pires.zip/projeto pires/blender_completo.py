import bpy
import glob
import os
import re

# ==============================================================================
# CONFIGURAÇÕES DE CAMINHO E PARÂMETROS
# ==============================================================================
PASTA_GLB = r"D:\PROJETOS\JIFIM\ProjetoPires-main\projeto pires\primeiro_teste"
PADRAO_ARQUIVO = "person_*.glb"

# ==============================================================================
# 1. LIMPEZA TOTAL DA CENA (REMOVE QUADROS SOBREPOSTOS/CONGELADOS)
# ==============================================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Função para ordenar numericamente (person_0.glb, person_1.glb, ..., person_10.glb)
def extrair_numero(caminho):
    nome = os.path.basename(caminho)
    numeros = re.findall(r'\d+', nome)
    return int(numeros[0]) if numeros else 0

arquivos_glb = sorted(glob.glob(os.path.join(PASTA_GLB, PADRAO_ARQUIVO)), key=extrair_numero)

if not arquivos_glb:
    raise FileNotFoundError(f"Nenhum arquivo .glb encontrado em: {PASTA_GLB}")

total_frames = len(arquivos_glb)
print(f"Total de {total_frames} arquivos .GLB encontrados. Montando animação limpa...")

# ==============================================================================
# 2. CARREGAMENTO E VINCULAÇÃO DO MODELO BASE (FRAME 0)
# ==============================================================================
bpy.ops.import_scene.gltf(filepath=arquivos_glb[0])

malha_principal = None
esqueleto_principal = None

for obj in bpy.context.scene.objects:
    if obj.type == 'MESH' and not malha_principal:
        malha_principal = obj
    elif obj.type == 'ARMATURE' and not esqueleto_principal:
        esqueleto_principal = obj

if not esqueleto_principal:
    raise ValueError("Não foi possível carregar o esqueleto mestre no arquivo GLB.")

# Garante que a malha corporal acompanhe o esqueleto de forma rígida
if malha_principal:
    malha_principal.parent = esqueleto_principal
    if not any(m.type == 'ARMATURE' for m in malha_principal.modifiers):
        mod = malha_principal.modifiers.new(name="Armature", type='ARMATURE')
        mod.object = esqueleto_principal

# Ajusta a exibição visual para octaedro simples (evita leques visuais poluídos)
esqueleto_principal.data.display_type = 'OCTAHEDRAL'

# Configuração da Timeline do Blender
bpy.context.scene.render.fps = 30
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = total_frames

# ==============================================================================
# 3. TRANSFERÊNCIA E GRAVAÇÃO DA ANIMAÇÃO NA TIMELINE
# ==============================================================================
for frame_idx, caminho_glb in enumerate(arquivos_glb, start=1):
    bpy.context.scene.frame_set(frame_idx)
    
    objetos_existentes = set(bpy.context.scene.objects)
    
    # Importa temporariamente o GLB do quadro atual
    bpy.ops.import_scene.gltf(filepath=caminho_glb)
    
    novos_objetos = list(set(bpy.context.scene.objects) - objetos_existentes)
    esqueleto_temp = None
    
    for obj in novos_objetos:
        if obj.type == 'ARMATURE':
            esqueleto_temp = obj
            break
            
    # Aplica as transformações dos ossos e insere os Keyframes no frame atual
    if esqueleto_temp:
        esqueleto_principal.location = esqueleto_temp.location
        esqueleto_principal.rotation_euler = esqueleto_temp.rotation_euler
        esqueleto_principal.keyframe_insert(data_path="location", index=-1)
        esqueleto_principal.keyframe_insert(data_path="rotation_euler", index=-1)
        
        for bone_temp in esqueleto_temp.pose.bones:
            if bone_temp.name in esqueleto_principal.pose.bones:
                bone_alvo = esqueleto_principal.pose.bones[bone_temp.name]
                
                bone_alvo.location = bone_temp.location
                bone_alvo.rotation_quaternion = bone_temp.rotation_quaternion
                bone_alvo.rotation_euler = bone_temp.rotation_euler
                
                bone_alvo.keyframe_insert(data_path="location", index=-1)
                if bone_temp.rotation_mode == 'QUATERNION':
                    bone_alvo.keyframe_insert(data_path="rotation_quaternion", index=-1)
                else:
                    bone_alvo.keyframe_insert(data_path="rotation_euler", index=-1)

    # Deleta imediatamente a cópia temporária para impedir a sobreposição de frames na Viewport
    bpy.ops.object.select_all(action='DESELECT')
    for obj in novos_objetos:
        obj.select_set(True)
    bpy.ops.object.delete(use_global=False)

# Re-seleciona a cena limpa e volta para o início da timeline
bpy.ops.object.select_all(action='DESELECT')
esqueleto_principal.select_set(True)
bpy.context.view_layer.objects.active = esqueleto_principal

bpy.context.scene.frame_set(1)

print(f"Sucesso! Todos os {total_frames} frames foram sincronizados na Timeline.")