"""
Gera uma imagem (PNG) com a análise de um agachamento a partir dos TXT de juntas.

Passo 1 - descobrir os índices das juntas (quadril, joelho, tornozelo):
    python grafico_agachamento.py --pasta convertidos --listar

Passo 2 - gerar o gráfico (índices = linha do TXT, começando em 0):
    python grafico_agachamento.py --pasta convertidos --fps 30 \
        --esq 10,11,12 --dir 20,21,22

Dependências: pip install numpy matplotlib scipy
"""
import argparse
import glob
import os
import re

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter

# Faixa ilustrativa de profundidade (ângulo do joelho no ponto mais baixo).
# Ajuste com o médico/fisioterapeuta.
FAIXA_MIN, FAIXA_MAX = 70, 110


def chave_natural(texto):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", texto)]


def ler_frame(caminho):
    """Lê um TXT. Aceita 'nome x y z' ou apenas 'x y z'."""
    nomes, pontos = [], []
    with open(caminho, encoding="utf-8") as f:
        for linha in f:
            p = linha.split()
            if len(p) < 3:
                continue
            pontos.append([float(v) for v in p[-3:]])
            nomes.append(p[0] if len(p) > 3 else "")
    return nomes, np.array(pontos)


def angulo(a, b, c):
    """Ângulo em graus no ponto b (a-b-c), para todos os frames de uma vez."""
    ba, bc = a - b, c - b
    cos = (ba * bc).sum(1) / (np.linalg.norm(ba, axis=1) * np.linalg.norm(bc, axis=1))
    return np.degrees(np.arccos(np.clip(cos, -1, 1)))


def suavizar(y):
    """Filtro Savitzky-Golay para reduzir o ruído da estimativa de pose."""
    n = len(y)
    janela = min(11, n if n % 2 == 1 else n - 1)
    return savgol_filter(y, janela, 3) if janela >= 5 else y


def detectar_repeticoes(ref, fps, prominencia):
    """Cada vale da curva é uma repetição. Devolve índices dos vales."""
    vales, _ = find_peaks(-ref, prominence=prominencia, distance=max(1, int(0.5 * fps)))
    return vales


def tempos_por_repeticao(ref, vales, fps):
    descidas, subidas = [], []
    for k, v in enumerate(vales):
        ini = vales[k - 1] if k > 0 else 0
        fim = vales[k + 1] if k + 1 < len(vales) else len(ref) - 1
        topo_antes = ini + int(np.argmax(ref[ini:v + 1]))
        topo_depois = v + int(np.argmax(ref[v:fim + 1]))
        descidas.append((v - topo_antes) / fps)
        subidas.append((topo_depois - v) / fps)
    return np.array(descidas), np.array(subidas)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pasta", default="convertidos")
    ap.add_argument("--padrao", default="juntas_quadro_*.txt")
    ap.add_argument("--fps", type=float, default=30)
    ap.add_argument("--esq", help="índices quadril,joelho,tornozelo esquerdos")
    ap.add_argument("--dir", help="índices quadril,joelho,tornozelo direitos")
    ap.add_argument("--prominencia", type=float, default=30,
                    help="queda mínima (graus) para contar uma repetição")
    ap.add_argument("--saida", default="grafico_agachamento.png")
    ap.add_argument("--listar", action="store_true",
                    help="mostra índice e nome de cada junta do 1º frame e sai")
    args = ap.parse_args()

    arquivos = sorted(glob.glob(os.path.join(args.pasta, args.padrao)), key=chave_natural)
    if not arquivos:
        raise SystemExit(f"Nenhum arquivo '{args.padrao}' em {args.pasta}")

    if args.listar:
        nomes, pts = ler_frame(arquivos[0])
        for i, (n, p) in enumerate(zip(nomes, pts)):
            print(f"{i:4d}  {n or '(sem nome)':30s} {p[0]:9.3f} {p[1]:9.3f} {p[2]:9.3f}")
        return

    lados = {}
    if args.esq:
        lados["Esquerdo"] = [int(i) for i in args.esq.split(",")]
    if args.dir:
        lados["Direito"] = [int(i) for i in args.dir.split(",")]
    if not lados:
        raise SystemExit("Informe --esq e/ou --dir (use --listar para ver os índices).")

    frames = [ler_frame(a)[1] for a in arquivos]
    n_nos = min(len(f) for f in frames)
    dados = np.stack([f[:n_nos] for f in frames])          # (frames, nós, 3)
    tempo = np.arange(len(frames)) / args.fps

    curvas = {}
    for lado, (q, j, t) in lados.items():
        bruto = angulo(dados[:, q], dados[:, j], dados[:, t])
        curvas[lado] = suavizar(bruto)

    ref = np.mean(list(curvas.values()), axis=0)
    vales = detectar_repeticoes(ref, args.fps, args.prominencia)
    n_reps = len(vales)
    if n_reps:
        desc, sub = tempos_por_repeticao(ref, vales, args.fps)

    # CSV com a série temporal
    with open(os.path.splitext(args.saida)[0] + ".csv", "w", encoding="utf-8") as f:
        f.write("frame,tempo_s," + ",".join(f"joelho_{l.lower()}_graus" for l in curvas) + "\n")
        for i in range(len(tempo)):
            f.write(f"{i},{tempo[i]:.3f}," + ",".join(f"{c[i]:.2f}" for c in curvas.values()) + "\n")

    # ------------------ Figura ------------------
    fig = plt.figure(figsize=(12, 8))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.6, 1])

    ax1 = fig.add_subplot(gs[0, :])
    ax1.axhspan(FAIXA_MIN, FAIXA_MAX, color="green", alpha=0.12,
                label=f"Faixa de referência no fundo ({FAIXA_MIN}°–{FAIXA_MAX}°)")
    for lado, c in curvas.items():
        ax1.plot(tempo, c, linewidth=2, label=f"Joelho {lado.lower()}")
    if n_reps:
        ax1.plot(tempo[vales], ref[vales], "kv", markersize=9, label="Ponto mais baixo")
        for k, v in enumerate(vales, 1):
            ax1.annotate(f"{k}", (tempo[v], ref[v]), textcoords="offset points",
                         xytext=(0, -16), ha="center", fontsize=9, fontweight="bold")
    ax1.set_title("Ângulo do joelho ao longo do agachamento", fontsize=14, fontweight="bold")
    ax1.set_xlabel("Tempo (s)")
    ax1.set_ylabel("Ângulo do joelho (graus)")
    ax1.set_ylim(0, 190)
    ax1.grid(alpha=0.3)
    ax1.legend(loc="lower right", fontsize=9)

    ax2 = fig.add_subplot(gs[1, 0])
    if n_reps:
        x = np.arange(1, n_reps + 1)
        largura = 0.8 / len(curvas)
        for i, (lado, c) in enumerate(curvas.items()):
            ax2.bar(x + (i - (len(curvas) - 1) / 2) * largura, c[vales],
                    width=largura, label=lado)
        ax2.axhspan(FAIXA_MIN, FAIXA_MAX, color="green", alpha=0.12)
        ax2.set_xticks(x)
        ax2.legend(fontsize=9)
    ax2.set_title("Profundidade por repetição (menor = mais fundo)")
    ax2.set_xlabel("Repetição")
    ax2.set_ylabel("Ângulo mínimo (graus)")
    ax2.grid(axis="y", alpha=0.3)

    ax3 = fig.add_subplot(gs[1, 1])
    ax3.axis("off")
    linhas = [f"Repetições detectadas: {n_reps}",
              f"Duração: {tempo[-1]:.1f} s  ({len(frames)} frames, {args.fps:g} fps)"]
    if n_reps:
        for lado, c in curvas.items():
            linhas.append(f"Profundidade média ({lado.lower()}): {c[vales].mean():.0f}°")
        if len(curvas) == 2:
            a, b = curvas.values()
            linhas.append(f"Assimetria média esq/dir: {np.mean(np.abs(a - b)):.1f}°")
        linhas.append(f"Tempo médio de descida: {desc.mean():.2f} s")
        linhas.append(f"Tempo médio de subida: {sub.mean():.2f} s")
        linhas.append(f"Variação de profundidade (1ª→última): "
                      f"{ref[vales][-1] - ref[vales][0]:+.0f}°")
    else:
        linhas.append("Nenhuma repetição encontrada: reduza --prominencia.")
    ax3.text(0, 1, "Resumo da sessão", fontsize=13, fontweight="bold", va="top")
    ax3.text(0, 0.88, "\n".join(linhas), fontsize=11, va="top", linespacing=1.8)

    fig.tight_layout()
    fig.savefig(args.saida, dpi=150)
    print(f"Gráfico salvo em {args.saida} | {n_reps} repetições")


if __name__ == "__main__":
    main()
