// Converte todos os person_N.glb em juntas_quadro_N.txt
// Cada linha do TXT: nome x y z   (posição GLOBAL do nó)
// Compilar (C++17): g++ -std=c++17 conversao_glb_para_txt.cpp -o conversao
#define CGLTF_IMPLEMENTATION
#include "C:\Users\IFMAKER\Documents\projeto pires\cgltf-master\cgltf.h"
#include <cstdio>
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

bool converterGlbParaTxt(const std::string& caminhoGlb, const std::string& caminhoTxt) {
    cgltf_options options = {};
    cgltf_data* data = NULL;

    if (cgltf_parse_file(&options, caminhoGlb.c_str(), &data) != cgltf_result_success) {
        std::printf("Erro ao carregar: %s\n", caminhoGlb.c_str());
        return false;
    }
    cgltf_load_buffers(&options, data, caminhoGlb.c_str());

    FILE* arquivo_txt = std::fopen(caminhoTxt.c_str(), "w");
    if (!arquivo_txt) {
        std::printf("Erro ao criar: %s\n", caminhoTxt.c_str());
        cgltf_free(data);
        return false;
    }

    for (cgltf_size i = 0; i < data->nodes_count; ++i) {
        cgltf_node* node = &data->nodes[i];

        // Matriz de transformação GLOBAL (já considera todos os pais).
        // A translação fica nas posições 12, 13 e 14 (matriz column-major).
        float m[16];
        cgltf_node_transform_world(node, m);

        // Nome sem espaços, para facilitar a leitura no Python.
        std::string nome = node->name ? node->name : "sem_nome";
        for (char& c : nome) if (c == ' ') c = '_';

        std::fprintf(arquivo_txt, "%s %f %f %f\n", nome.c_str(), m[12], m[13], m[14]);
    }

    std::fclose(arquivo_txt);
    cgltf_free(data);
    return true;
}

int main() {
    fs::create_directories("convertidos");

    // Converte person_0.glb, person_1.glb, ... até faltar um arquivo.
    int convertidos = 0;
    for (int i = 0;; ++i) {
        std::string entrada = "primeiro_teste/person_" + std::to_string(i) + ".glb";
        if (!fs::exists(entrada)) break;
        std::string saida = "convertidos/juntas_quadro_" + std::to_string(i) + ".txt";
        if (converterGlbParaTxt(entrada, saida)) ++convertidos;
    }

    std::printf("%d arquivos convertidos.\n", convertidos);
    return 0;
}
